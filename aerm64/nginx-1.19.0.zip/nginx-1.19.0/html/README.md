Files in here will not be processed by webpack, but instead copied over the the build folder.
