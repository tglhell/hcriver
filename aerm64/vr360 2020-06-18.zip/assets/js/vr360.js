$(function(){
	var vr360Btn = $('.btn-vr360 [data-icon="round-arrow"]');
	var vr360Box = $('.vr360-box');
	
	$.fn.extend({
		vr360Init: function(value) {
			vr360Init(this.selector, value);
			return
		}
	});

	var vr360Init = function (tarName,value) {
		this.selector = $(tarName);
		this.imagePath = value.imagePath;
		this.totalImages = value.totalImages;
		this.imageExtension = value.imageExtension || "png";
		this.isMoving = false;
		this.currentX = 0;
		this.currentImage=1;

		function chkStart() {
			selector.mousedown(function(target) {
				isMoving = true;
				currentX = target.pageX - this.offsetLeft;
			});

			$(document).mouseup(function() {
				isMoving = false;
			});

			selector.mousemove(function(target) {
				if (isMoving == true) {
					chkLoadImg(target.pageX - this.offsetLeft);
				}
			});

			selector.on('touchstart', function(target) {
				isMoving = true;

				var actualTouch = target.originalEvent.touches[0] || target.originalEvent.changedTouches[0];
				currentX = actualTouch.clientX;
			});

			$(document).on('touchend', function() {
				isMoving = false;
			});

			selector.on('touchmove', function(target) {
				target.preventDefault();
				var actualTouch = target.originalEvent.touches[0] || target.originalEvent.changedTouches[0];
				if (isMoving == true) {
					chkLoadImg(actualTouch.pageX - this.offsetLeft);
				} else {
					currentX = actualTouch.pageX - this.offsetLeft
				}
			});
		}

		function chkLoadImg(newX) {
			if (currentX - newX > 25 ) {
				currentX = newX;
				currentImage = --currentImage < 1 ? totalImages : currentImage;
				selector.css("background-image", "url(" + imagePath + currentImage + "." + imageExtension + ")");
			} else if (currentX - newX < -25) {
				currentX = newX;
				currentImage = ++currentImage > totalImages ? 1 : currentImage;  
				selector.css("background-image", "url(" + imagePath + currentImage + "." + imageExtension + ")");
			}
		}

		function vr360ImageLoad() {
			var loadedImages = 2;
			var appropriateImageUrl = imagePath + "1." + imageExtension;
			selector.css("background", "url(" + appropriateImageUrl + ") no-repeat center center");
				
			$("<img/>").attr("src", appropriateImageUrl).load(function() {
				selector.height(this.height).width('100%');
			});

			for (var n = 2; n <= totalImages; n++) {
				appropriateImageUrl = imagePath + n+"." + imageExtension;
				selector.append("<img src='" + appropriateImageUrl + "' style='display:none;'></div>");
				$("<img/>").attr("src", appropriateImageUrl).css("display", "none").load(function() {
					loadedImages++;
					if (loadedImages >= totalImages) {
						vr360Btn.parent().click(function(){
							vr360Btn.parent().remove();
							chkStart();
						});
					}
				});
			}
		}

		function sltReset() {
			vr360Btn.parent().show();
			selector.find('img').remove();
		}

		setTimeout(function(){
			vr360ImageLoad();
			sltReset();
			vr360Box.css('cursor', 'ew-resize');
		}, 1000);
	}
	
	if (vr360Btn.parent().length == 1) {
		vr360Btn.append('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path class="st0" d="M67.6,17.3c-5.2-2.8-11.1-4.4-17.4-4.4c-20.3,0-36.7,16.4-36.7,36.7c0,20.3,16.4,36.7,36.7,36.7 s36.7-16.4,36.7-36.7c0-7.1-2-13.7-5.5-19.4"></path><path class="st1" d="M79.1 35.4L81.2 30 86.7 32.1"></path></svg>');
	}

	vr360Box.vr360Init({
		imagePath: "./assets/images/",
		totalImages: 51,
		imageExtension: "png"
	});
});