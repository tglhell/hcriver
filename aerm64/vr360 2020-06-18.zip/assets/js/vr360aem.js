$(function(){
	$.fn.extend({
		vr360Init: function(value) {
			vr360Init(this.selector, value);
			return
		}
	});

	var vr360Init = function (tarName,value) {
		this.selector = $(tarName);
		this.imagePath = value.imagePath;
		this.totalImages = value.totalImages;
		this.imageExtension = value.imageExtension || "jpg";
		this.isMoving = false;
		this.currentX = 0;
		this.currentImage=1;

		function chkStart() {
			selector.mousedown(function(target) {
				isMoving = true;
				currentX = target.pageX - this.offsetLeft;
			});

			$(document).mouseup(function() {
				isMoving = false;
			});

			selector.mousemove(function(target) {
				if (isMoving == true) {
					chkLoadImg(target.pageX - this.offsetLeft);
				}
			});

			selector.on('touchstart', function(target) {
				isMoving = true;

				var actualTouch = target.originalEvent.touches[0] || target.originalEvent.changedTouches[0];
				currentX = actualTouch.clientX;
			});

			$(document).on('touchend', function() {
				isMoving = false;
			});

			selector.on('touchmove', function(target) {
				target.preventDefault();
				var actualTouch = target.originalEvent.touches[0] || target.originalEvent.changedTouches[0];
				if (isMoving == true) {
					chkLoadImg(actualTouch.pageX - this.offsetLeft);
				} else {
					currentX = actualTouch.pageX - this.offsetLeft
				}
			});
		}

		function chkLoadImg(newX) {
			if (currentX - newX > 25 ) {
				currentX = newX;
				currentImage = --currentImage < 1 ? totalImages : currentImage;
				selector.css("background-image", "url(" + imagePath + currentImage + "." + imageExtension + ")");
			} else if (currentX - newX < -25) {
				currentX = newX;
				currentImage = ++currentImage > totalImages ? 1 : currentImage;  
				selector.css("background-image", "url(" + imagePath + currentImage + "." + imageExtension + ")");
			}
		}

		function vr360ImageLoad() {
			var loadedImages = 2;
			var appropriateImageUrl = imagePath + "1." + imageExtension;
			selector.css("background", "url(" + appropriateImageUrl + ") no-repeat center center");
				
			$("<img/>").attr("src", appropriateImageUrl).load(function() {
				// selector.height(this.height).width('100%');
				selector.height('600px').width('100%');
			});

			for (var n = 2; n <= totalImages; n++) {
				appropriateImageUrl = imagePath + n+"." + imageExtension;
				selector.append("<img src='" + appropriateImageUrl + "' style='display:none;'></div>");
				$("<img/>").attr("src", appropriateImageUrl).css("display", "none").load(function() {
					loadedImages++;
					if (loadedImages >= totalImages) {
						$('.loading-box').click(function(){
							$(".loading-box").hide();
							$(".loading-box").text("");
							chkStart();
						});
					}
				});
			}
		}

		function loadingBox() {
			$(selector).html("<div class='loading-box'><button class='btn-vr'><span>Loading Complete!!</span></button></div>");
		}

		setTimeout(function(){
			vr360ImageLoad();
			loadingBox();
		}, 1000);
	}

	// vr360 Initialing
	$('.vr360aem-box').vr360Init({
		imagePath: "./assets/images/aem64/",
		totalImages: 36,
		imageExtension: "jpg"
	});
});